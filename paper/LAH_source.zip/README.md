# LAH — published Zenodo DOI update

The paper and current resources cite the verified version DOI https://doi.org/10.5281/zenodo.24036084. Zenodo's published file size and MD5 match the exact prepared reproducibility ZIP, which is preserved unchanged in the authoring archive. Its scientific code/data remain unchanged. The current paper adds that archival link; it is a subsequent local document update, not a silent replacement of Zenodo's deposited file.

Six availability/contribution/privacy paragraphs change to identify the public materials and remove obsolete confidential-copy/preparation wording. The author also expressly licensed owned study code and synthetic data under CC BY4.0; LICENSE.md and NOTICE.md state the scope. Third-party notices remain separate. The title, abstract, AI declaration, all numerical results, eight tables,31literature references and four figures are unchanged.

CITATION.cff and CITATION.bib identify the software/materials DOI. It is not a separately assigned manuscript or arXiv DOI. No arXiv identifier, submission or acceptance is inferred. Current checks cover exact content deltas, DOI identity/hyperlinks, unchanged tables/citations/figures, PDF layout and clean-source compilation. Earlier all-claims integrity remains prior-revision history.

The companion repository is https://github.com/lifesight/lah-paper-experiments. Current changes are prepared locally for the author to commit and push. Remote GitHub contents and the published Zenodo files were not changed. See BUILD.md for source compilation.
