# Build the manuscript

The portable source package contains a self-contained `article` LaTeX file, its four figures in PDF/PNG/SVG, the citeproc bibliography inputs (`references.bib`, `ieee.csl`), clean Markdown with citation keys, resolved IEEE Markdown, the open-license Latin Modern Roman/Mono/Math fonts and their GUST license, and the two implementation-evidence sidecars referenced by Appendix C. The `.tex` has a rendered bibliography and requires no BibTeX/Biber pass. Its graphics use relative paths.

Compile from the extracted package directory with Tectonic:

```sh
tectonic --untrusted --only-cached --keep-logs LAH_Marketing_Measurement.tex
```

`--only-cached` requires the standard TeX package bundle already cached. The supplied PDF was built using Tectonic 0.17.0, Pandoc 3.13, the cached package bundle, and the relative open-license fonts supplied in `fonts/`. No operating-system font registry or Mac-specific path is needed. An installation without cached packages can provision its normal TeX dependencies separately, or compile the same source with XeLaTeX (`xelatex LAH_Marketing_Measurement.tex`, run twice). XeLaTeX is an arXiv-supported engine; choose **XeLaTeX** when uploading `LAH_arXiv_source.zip` to arXiv. The author-selected primary category is **cs.AI** and manuscript distribution license is **CC BY 4.0**. Review the generated server PDF before submitting; this local build does not establish server compilation or moderation outcome. After arXiv Check Files, select compiler `xelatex`, root file `LAH_Marketing_Measurement.tex`, and TeX Live 2025. The UI normally generates its own `00README.json`; this package does not add a competing configuration file. See the [official arXiv compiler configuration guidance](https://info.arxiv.org/help/00README.html). The bibliography is already rendered, so no external `.bbl` is needed.

To regenerate the resolved IEEE Markdown from the clean citation-key source with Pandoc:

```sh
pandoc manuscript_source.md --from=markdown+tex_math_single_backslash --to=gfm --citeproc --bibliography=references.bib --csl=ieee.csl --wrap=none -o LAH_Marketing_Measurement.md
```

This is a generic academic preprint layout with IEEE numbered citations. It does not assert compliance with an IEEE journal, conference template, or an arXiv submission policy. No venue was selected, so no cover letter or venue-specific declarations were generated.

The source package includes `figure-source/render_architecture.py` and its relative `architecture_layout.original.json`. With Python 3.11 and Matplotlib installed, run that renderer from its folder to regenerate the approved architecture figure. It retains all nine inspected interfaces and ten relations, with the author-requested explanatory annotation panel removed and the measured component centered. The other three quantitative figures are retained unchanged from the public source baseline. The manuscript title page intentionally has no date.
