# Final candidate — frozen synthetic NumberLedger component evaluation

**Status:** ready for independent review and root freeze; main execution not authorized by this file. Root already executed the separate machinery pilot `pilot001`: seed 9001, 8/80 sources, five instances per family, 120 scored instances, zero checker exceptions and zero retries. Reviewer independently checked pilot rows, gold alignment, calls and retained-state conservation. The pilot inputs/results remain unchanged. `PILOT001_RUNNER_ab09815e.py` preserves the exact runner, which is unchanged for main execution.

## Fixed execution inventory

Run seeds 1001–1010, each at source volumes 8, 80 and 800, eight facts per source, 100 scored instances for each of twelve families: 30 cells, 1,200 instances/cell, 36,000 scored claim instances total. These are **not 36,000 unique cases**. Deterministic age-stratified selection repeats claim texts in small inventories; report observed unique text counts for every cell/family. Independent sampling unit is the seed, not a claim, source, repeated instance or volume cell. Ten independently generated seed populations support only conditional descriptive sampling uncertainty.

Each cell has six nominally full-fact-correct families (600 instances): direct exact, compact direct, sum, signed difference, named ratio, percentage. Six altered families (600 instances): random value, near value, wrong entity, wrong date, wrong currency, wrong sign. Independent source/claim oracle determines actual labels. Numeric-support classes may differ from the nominal semantic classes because of coincidence and rounding; preserve actual denominators. There are no result-based exclusions or extra trials to improve scores. All cells are fixed before main execution.

Source payloads contain two entities × spend/revenue/cost/margin, explicit fact/source IDs, January 2026 dates, currency unit and USD. Decimal construction values become floats only in SUT payloads. Same seed shares its generation prefix across volumes, but age-stratified query identities/displays vary with volume: these are descriptive stress conditions, not a causal same-claim evidence-growth or cap effect. All arms inside a cell see identical evidence and text.

## What is measured

Current unmodified `harness-core/harness_core/provenance.py`, repository HEAD `744d96938daabb8be0c83974c78b0348b8fc2ac2`, source SHA256 `c90e00fde672964e208f6e18ae415c83a4296267c9d3c4e1cfaa52e7ea081a02`. Source is copied and imported in isolation, avoiding runtime vendors. No SUT constants are mutated. Actual default bounds remain in force and are recorded. No production edits, commits, pushes, private exports, platform requests, cloud calls or LLM calls.

The public component paths are `NumberLedger.explained(text)` and `find_ungrounded(text)`. They receive the identical canonical JSON claim text, which explicitly names operation, operands, binding and displayed value. `explained` target acceptance and all-token text acceptance are separate outputs; `find_ungrounded` is whole-text acceptance. The current plugin's later `cross_derivation()` treatment, final formatter, gate and model behavior are outside this component study. A helper is never credited as successful end-to-end checking.

Current named-ratio behavior is already production code: newly derived multiplier prose checks its displayed operands, while a directly grounded multiplier remains grounded even if subsequent operand prose is inconsistent. No historical patch or repaired reference implementation is presented as current LAH.

Comparators are independently implemented Decimal raw-only target checks: `direct_retained` uses raw fact values retained in actual source values; `direct_full_inventory` uses all raw facts as a descriptive availability reference. They share claim text/evidence but differ explicitly in matching, grammar, exemption and derivation policies. They exclude totals/groups/pairwise/restatement support and do not validate bindings or displayed operands. They are descriptive comparators, not a controlled production ablation or final-formatter equivalent. Compare their target decision only with current explained target decision. No source-bound reference checker is scored because reusing the semantic oracle would make that comparator tautological.

## Independent correctness labels

Full-fact truth uses source records and Decimal arithmetic, without importing SUT matching logic. Direct facts require exact identity binding. Sum/difference require identical metric/unit/date/currency; asserted aggregate entity is `all` for sums and `contrast` for signed differences. Revenue/spend ratio or revenue share requires the same entity, window and currency. Numeric rounding is Decimal half-even at written precision floored at two and capped at six significant digits. Canonical display grammar accepts signed decimal, K/M, x/% and explicit decimal ratio operands. No currency conversion, arbitrary cross-metric sum or unknown metadata is silently permitted.

A separate finite numeric-support oracle enumerates signed raw values and within-source pair sums/differences/ratios/shares/relative changes, ignoring bindings. A random perturbation that collides is numerically supported under that policy. **This finite oracle does not enumerate all LAH aggregation, group, count and restatement rules.** An acceptance labeled unsupported under this finite policy is not automatically a production numeric error. Full-fact incorrect acceptance is a semantic scope diagnostic; NumberLedger is not promised to verify entity/date/currency binding. These software labels do not establish natural-language interpretation or underlying marketing/causal truth.

Hand-expected validation cases cover direct/sign/entity/sum/named ratio, mismatched displayed operands/dates, rounding and numeric collision/source-split cases, including a six-digit-capped rounding-window counterexample identified and fixed during development. Reviewer ran 7 semantic and 7 numeric checks before pilot. No production mechanism was changed by that oracle repair.

## Availability and retained state

Record complete actual state per cell: held/exact values, all source values/bases/operands/counts/named fields/currencies/group families, and global totals/groups. Values/bases can evict while other bands persist; raw retention is never substituted for checkability. Every full inventory fact is also passed once to explained as direct fact text, recording public quotability and explanation. This observes numeric quotability, not retained semantic identity.

Report full inventory raw retention, direct-fact-text quotability, correct acceptance conditional on all named operands' raw retention, and fixed full-inventory claim retention separately. The conditional rate is specifically raw-support conditional, not a claim that every derived support band is exhausted. No memory/candidate-search complexity estimate is inferred from cap or source count.

## Calls, failures and timing

Expected main calls: 36,000 explained scored calls, 36,000 find_ungrounded scored calls, 72,000 direct-baseline calls = 144,000 scored arm calls. Additionally 71,040 source facts receive one availability explained call. Because each find_ungrounded invokes explained internally, expected explained traversals are 143,040. These denominators are separate and checked against observations. Source additions total 8,880 over 30 fresh ledgers.

Record cold first-pass wall times with `perf_counter_ns`, build time separately, individual checking time per arm, and availability checking time separately. No warm-up, repeat-timing stability claim, peak memory or internal candidate-count claim. Pilot calibrated only 8/80-source machinery, not 800-source runtime. Reserve up to 15 minutes for fixed main execution plus up to 10 minutes for analysis; a timeout records partial completion rather than dropping slow/bad cells. No significance- or score-dependent stopping. Root may set a wider administrative time limit before execution, preserving the entire fixed inventory.

All checker failures, missing decisions, unsupported/no-parse coverage, exemptions and retries remain explicit. No retries are automatic. `find_ungrounded` can vacuously accept a no-parse text; explained coverage is reported rather than calling it verified. Original run bundles and failed attempts are immutable; any rerun gets a new run ID and remains visible. No selectively repaired main output.

## Frozen analysis

`analyze_v2.py` writes per-family/cell confusion counts, actual rates/denominators, each seed's rates, paired target differences, cost and availability tables, unique-text counts and design integrity checks. Semantic and finite numeric endpoints stay separate. It checks rows/unique IDs, input/gold/observation alignment, four arms, per-arm call count, checker exceptions and complete 30-cell/36,000-instance/144,000-arm-call inventory. Any failed/absent cell or checker exception yields a partial integrity record; no completed main claim.

For target comparison with each raw comparator, paired complete decisions define the paired denominator; preserve excluded missing-pair counts and full truth-class denominators. Compute current acceptance, baseline acceptance and their paired difference per seed × volume × family × truth axis/class. Seed-macro points expose eligible seed IDs/counts and undefined strata. Undefined seed rates are never zero-filled. If all ten main seeds have nonzero paired denominators, use the same 10,000 jointly resampled seed-ID lists for every contrast, RNG seed 740031. Report linear-interpolated 2.5th/97.5th percentiles of seed-macro rates/differences. Otherwise no interval, with explicit reason; available-seed point estimates remain descriptive and labeled.

These are **pointwise descriptive 95% seed-cluster bootstrap intervals** with ten seeds, without simultaneous/multiplicity-adjusted coverage, significance tests or power guarantees. No claim-level IID intervals, pooled universal accuracy, deployment prevalence, customer-population inference or favorable significance stopping.

## Scope and remaining gaps

Call the result a **prospectively frozen synthetic component evaluation**. Seed IDs are uninspected by the scored run, but the generator, family design and case distributions are development material; no independent held-out domain or prospective confirmatory label is warranted.

Dedicated exemptions/year/small-percent thresholds, locale/unsupported syntax, unspoken ratios, zero handling, incorrect named-operand and conflict patterns are not comprehensively sampled. Captured-data scoring is excluded from this main cohort. Seven existing episodes and newly reconstructed current tool returns may support a separately frozen exploratory replay, preserving failures/capture misses and full-fact unknowns; they do not complete fresh E02's 30-episode target. No E03 historical-patch comparison, full plugin study, live LLM study or end-to-end compliance is claimed. No full E01–E03 completion claim follows automatically.

Root issues a hash-bound permit only after independent reviewer gate. Run records must preserve protocol/hash, exact runner/analyzer/SUT hashes, Python/platform/time, permit, source snapshot, constants, immutable inputs and labels, retained state, availability, per-instance observations, all attempts and generated analysis. A local freeze is not a public preregistration or publication authorization.
