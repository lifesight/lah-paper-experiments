# LAH synthetic component reproduction candidate

PRIVATE local release candidate, prepared 2026-11-07. Nothing has been uploaded or published. Rights and a license remain pending; see LICENSE_STATUS.json. Preparation of synthetic code/data and aggregate results was authorized. Raw workspace data stays private.

## Run

Requires Python 3.11 or newer and its standard library only. No installation, repository checkout, network, API credential, model, cloud service, Google ADK or platform service is needed.

From the extracted package directory, run this single command with a new output directory outside the package:

```sh
python3 reproduce.py --output ../lah-verification
```

The command checks every packaged file against FILE_MANIFEST.json, checks five frozen identities against the original permit, replays seed 1001 at eight sources with the unchanged component, compares every input/gold/state/availability/decision against original cell_000, reanalyzes the complete existing 30-cell bundle with the unchanged analyzer, compares all analysis content except its bundle path, and checks Table 4 arithmetic. Analysis has 10,000 bootstrap draws and may take several minutes. Original observations are approximately 139 MB uncompressed; memory needs exceed the input size because the frozen analyzer retains observations in memory. A first run in the preparation environment used Python 3.12; validation receipts outside the archive record observed time and memory where available.

For separate checks:

```sh
python3 reproduce.py --mode verify
python3 reproduce.py --mode smoke --output ../lah-smoke
python3 reproduce.py --mode analysis --output ../lah-analysis
```

The adapter refuses to overwrite an existing output directory and writes no bytecode into the package. If interrupted, retain that partial directory and choose a new output directory for another attempt. No automatic retries occur. The default command does not freshly rerun all 30 benchmark cells; it reanalyzes their original data and freshly replays one cell as a portability check.

## What is included

- `frozen/`: exact original runner, analyzer, final protocol, review gate and original MAIN001 permit. Their preparation/status strings are preserved as historical bytes, including pending strings. The original run's `completion.json` and analysis integrity establish completed execution.
- `original/main001/`: all 30 synthetic cells, original inputs, gold labels constructed independently of NumberLedger matching, complete retained state, availability checks, observations, attempts, original source snapshot and constants. No SUT constant, rounding rule, default, source, oracle or decision has been changed.
- `original/main001_analysis/`: exact original analysis products. Original timing is retained separately from newly generated replay timing, in these original cost tables and original cell summaries/observations. Timing equality is never a semantic test.
- `aggregate/table4_counts.json`: only count rows and provenance digest for seven pseudonymous development groups. This is aggregate recorded-data reporting, **not synthetic data**. Raw recordings, arguments, HTTP payloads, identifiers, source leaves and recorded cohort artifacts are absent. Table 4 can be checked for accounting only; the private recorded-data analysis cannot be independently rerun from this package.
- `reproduce.py`: a **new portability adapter**. It imports the exact frozen runner and calls `load_sut`, `validate_cases` and `run_cell`; it invokes the unchanged analyzer's `main` with portable paths. It does not call the frozen runner's machine-specific `main`, change its REPO constant, fake repository HEAD, mint an original permit, or pretend a new check is the original run.
- `PROVENANCE.json`, `FILE_MANIFEST.json`, `LICENSE_STATUS.json`: origin mapping, SHA256/size/allowlist and explicit release/rights limits. FILE_MANIFEST.json enumerates every other package file; its own SHA256 is supplied alongside the archive, avoiding a self-hash.

Exact frozen artifacts retain author-local source path strings and repository identity as provenance. The adapter never follows those paths or requires the original git repository. These known provenance strings are listed in the preparation scan receipt outside the archive. No raw workspace data accompanies them. If a future public release needs path redaction, retain the immutable originals and label any sanitized derivative separately with new hashes.

## Interpretation and limits

This is a prospective fixed-seed exploratory **NumberLedger component evaluation**, conditional on one pinned source, generator and canonical claim grammar. Thirty cells contain 36,000 repeated claim instances from ten seed populations, with 144,000 scored arm calls and 71,040 additional availability calls. Instances are not 36,000 independent or unique cases. The finite numeric policy is not exhaustive LAH support; semantic bindings exceed the numeric-only component's promise. Comparators differ in matching/grammar/exemption/derivation policy. Seed-cluster intervals are pointwise descriptive, not confirmatory population inference.

The package is not a fresh full-harness measurement, live-model evaluation, independent replication, public preregistration, original historical egress reconstruction, completion of E01–E03, or validation of underlying marketing/causal estimates. Raw workspace data is not available here. No open-source or data license is inferred from authorization to prepare this candidate. Actual public release, rights clearance and license selection remain unresolved.

## Label implementation dependency

The synthetic generator and full-fact checker share the frozen runner’s derive() and display/rounding helpers. Label independence is from the system under test, not complete software independence between generation and checking. Shared specification or helper defects remain a limitation. The review-era clarification changes no frozen generator, labels, observations, component or analysis.
